 --- DREAM TEAM SOFTWARE PRESENTS TO YOU ---
   _____    __________________  __      __  _____ __________  _________
  /  _  \   \      \__    ___/ /  \    /  \/  _  \\______   \/   _____/
 /  /_\  \  /   |   \|    |    \   \/\/   /  /_\  \|       _/\_____  \ 
/    |    \/    |    \    |     \        /    |    \    |   \/        \
\____|__  /\____|__  /____|      \__/\  /\____|__  /____|_  /_______  /
        \/         \/                 \/         \/       \/        \/ 

Running instructions:

Unzip to a folder and double-click on the JAR file. Depending on your
computer's configuration, you may have to execute it from the command
line using "java -jar antwars.jar". Note that due to the design of the
Java virtual machine, it is not possible to run this from a UNC (server)
path - you will have to execute it locally (for instance, on the C: drive).

HAPPY ANTING!
 - Dream Team Software

Project Manager: Kerry Hutchings
Programming and Design Leader: Davorin Kopic 
UI, UX, Audio and Music: Joseph Beahan 
Quality Assurance Manager: Kornelia Ratusznik 
Project Representative: Kieran King 

Group Coursework Project, by the specification for Software Engineering module at the University of Sussex, Brighton UK.

Most of the material used in the Ant Wars game is originally produced by the team.
Many thanks to:
Slick2D, Java 2D Game Library - http://slick.ninjacave.com/
k//eternal, Start Screen Music (from NEX theme for stepmania 3.9) - http://stepmaniathings.com/downloads/themes/sm-39/nex.html

April 2014, University of Sussex, Brighton, United Kingdom
